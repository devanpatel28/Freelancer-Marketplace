package com.example.code_with_patel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
